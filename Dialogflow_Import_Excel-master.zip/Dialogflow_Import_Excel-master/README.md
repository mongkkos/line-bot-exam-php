# Dialogflow_Import_Excel

This project for import intent from Excel template to Dialogflow.<br>
It use Dialogflow APIV1.<br>
Set Developer access token and loacl Excel template in app.config<br>
