﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiaImport003.model
{
    public class ExcelView
    {
        public String number { get; set; }
        public String intent { get; set; }
        public String Trainingphrases { get; set; }
        public String Responses { get; set; }
    }
}
